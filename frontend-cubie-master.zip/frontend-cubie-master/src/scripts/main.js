(function ($, window, document, undefined) {

  'use strict';

  $(function () {
    // Add your scripts here
  });

})(Zepto, window, document);